@extends('layout.masterlayout')

@section('title','test1')

@section('nav')
    <p>This is extends nav</p>
@endsection

@section('main')
    <p>This is extends main</p>
@endsection