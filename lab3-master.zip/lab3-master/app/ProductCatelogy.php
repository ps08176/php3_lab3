<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductCatelogy extends Model
{
    //
    protected $table='product_catelogies';
    protected $primaryKey ='product_id';
}
