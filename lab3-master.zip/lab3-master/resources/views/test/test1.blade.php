@extends('layout.masterlayout')

@section('title', 'Test1')

@section('nav')
    <p>hihi</p>
    <p>this is extended nav</p>
@endsection

@section('main')
    <p>this is extended main</p>
@endsection